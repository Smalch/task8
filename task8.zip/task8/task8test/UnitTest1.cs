﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace task8test
{

    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var expected = new List<task8.Kom> { new task8.Kom { Number_of_house=100, Number_of_flat=100, Last_name="A",Type='e',Data = new DateTime(2020, 7, 20),Sum=1200,Prochent=0.1,Pr=0},
            new task8.Kom { Number_of_house=101, Number_of_flat=101, Last_name="A",Type='e',Data = new DateTime(2020, 7, 20),Sum=1200,Prochent=0.1,Pr=0},
            new task8.Kom { Number_of_house=102, Number_of_flat=102, Last_name="B",Type='g',Data = new DateTime(2020, 6, 19),Sum=1100,Prochent=0.12,Pr=3},
            new task8.Kom { Number_of_house=103, Number_of_flat=103, Last_name="C",Type='w',Data = new DateTime(2019, 7, 20),Sum=1000,Prochent=0.13,Pr=5},
            new task8.Kom { Number_of_house=104, Number_of_flat=104, Last_name="D",Type='r',Data = new DateTime(2020, 7, 6),Sum=1500,Prochent=0.14,Pr=13},
            new task8.Kom { Number_of_house=105, Number_of_flat=105, Last_name="E",Type='e',Data = new DateTime(2020, 2, 20),Sum=1800,Prochent=0.15,Pr=10}};

            IEnumerable<task8.Kom> actual = task8.Kom.Create_start_values();
            List<task8.Kom> ans = new List<task8.Kom>();
            int y = 1;
            //MessageBox.Show(Convert.ToString(delet));
            foreach (var i in actual)
            {
                ans.Add(i);
            }

            Assert.AreEqual(expected.Count, ans.Count);
        }


        [TestMethod]
        public void TestMethod2()
        {
            task8.Form1 f = new task8.Form1();
            bool actual = f.Check();

            var expected = false;
            Assert.AreEqual(expected, actual);
        }
    }
}
